﻿export function setTitle(title) {
    document.title = title;
}
